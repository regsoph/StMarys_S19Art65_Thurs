# StMarys_S19Art65_Thurs
Repository for student work (St. Mary's College of CA, S19 Art-65)

Submit your completed assignments to your branch of the repository or per instructions you receive in class or on Moodle.
